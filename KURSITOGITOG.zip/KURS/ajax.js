$(document).ready(function() {
    $("#feedbackForm").on("submit", function(event) {
        event.preventDefault(); 

        $.ajax({
            url: "http://localhost:3000/send-feedback", 
            type: "POST", 
            data: $(this).serialize(), 
            success: function(response) {
                alert("Сообщение успешно отправлено!");
                $("#feedbackForm")[0].reset(); 
            },
            error: function(xhr, status, error) {
                alert("Произошла ошибка при отправке данных: " + error);
            }
        });
    });
});