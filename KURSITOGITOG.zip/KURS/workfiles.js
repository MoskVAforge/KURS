document.getElementById('uploadForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const fileInput = document.getElementById('file');
    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('file', file);

    fetch('http://localhost:3000/index.html', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert('Файл успешно загружен');
        document.getElementById('uploadForm').reset();
    })
    .catch(error => {
        alert('Ошибка при загрузке файла');
        document.getElementById('uploadForm').reset();
    });
});