//Услуги
document.addEventListener('DOMContentLoaded', () => {
    const services = document.querySelectorAll('.service');
    const modal = document.getElementById('modal');
    const modalText = document.getElementById('modal-text');
    const closeButton = document.querySelector('.close-button');

    const serviceDetails = {
        'audit': `
            <h3>Аудит</h3>
            <p>Аудит – это независимая проверка финансовой отчетности вашей компании, направленная на подтверждение её достоверности. Наши специалисты проводят всесторонний анализ ваших финансовых документов, чтобы выявить возможные ошибки и несоответствия, а также предложить пути их устранения.</p>
            <ul>
                <li>Проверка бухгалтерских и налоговых отчетов</li>
                <li>Анализ финансовых операций и внутренних процессов</li>
                <li>Рекомендации по улучшению учета и отчетности</li>
                <li>Соответствие требованиям законодательства</li>
            </ul>
            <p>Мы гарантируем точность и объективность наших заключений, что поможет вам повысить доверие инвесторов и партнеров к вашему бизнесу.</p>
        `,
        'consulting': `
            <h3>Консультации</h3>
            <p>Наши консультационные услуги охватывают широкий спектр вопросов в области бухгалтерского учета и налогообложения. Мы помогаем вам оптимизировать налоговые обязательства и обеспечить соответствие законодательству.</p>
            <ul>
                <li>Консультации по налогообложению и налоговому планированию</li>
                <li>Советы по бухгалтерскому учету и финансовой отчетности</li>
                <li>Помощь в подготовке налоговых деклараций</li>
                <li>Рекомендации по улучшению внутреннего контроля</li>
            </ul>
            <p>Наша цель – предоставить вам знания и инструменты для эффективного управления финансами вашей компании.</p>
        `,
        'accounting': `
            <h3>Ведение бухгалтерии</h3>
            <p>Мы предлагаем полный спектр бухгалтерских услуг, чтобы обеспечить точность и своевременность вашей финансовой отчетности. Наши профессионалы ведут бухгалтерский учет, освобождая вас от рутины и позволяя сосредоточиться на развитии бизнеса.</p>
            <ul>
                <li>Ежедневное ведение бухгалтерских операций</li>
                <li>Подготовка и сдача бухгалтерской отчетности</li>
                <li>Учет основных средств и ТМЦ</li>
                <li>Контроль за правильностью налоговых расчетов</li>
            </ul>
            <p>Мы гарантируем высокое качество услуг и полное соответствие требованиям законодательства.</p>
        `,
        'registration': `
            <h3>Регистрация компаний</h3>
            <p>Мы предлагаем полный комплекс услуг по регистрации новых компаний. Наши специалисты помогут вам пройти все этапы, от выбора организационно-правовой формы до получения всех необходимых документов.</p>
            <ul>
                <li>Консультации по выбору организационно-правовой формы</li>
                <li>Подготовка учредительных документов</li>
                <li>Подача документов в налоговые органы</li>
                <li>Получение свидетельства о регистрации</li>
            </ul>
            <p>С нами процесс регистрации пройдет быстро и без проблем, позволяя вам сосредоточиться на старте вашего бизнеса.</p>
        `,
        'due-diligence': `
            <h3>Проверка контрагентов</h3>
            <p>Наша услуга по проверке контрагентов помогает вам минимизировать риски и принимать обоснованные решения при выборе деловых партнеров. Мы проводим всесторонний анализ финансовой устойчивости и репутации потенциальных контрагентов.</p>
            <ul>
                <li>Анализ финансовых показателей</li>
                <li>Проверка на наличие судебных разбирательств</li>
                <li>Оценка деловой репутации</li>
                <li>Выявление рисков и рекомендации по их снижению</li>
            </ul>
            <p>Мы предоставляем надежную информацию, чтобы вы могли уверенно строить свои деловые отношения.</p>
        `,
        'hr-management': `
            <h3>Кадровый учет</h3>
            <p>Мы предоставляем услуги по ведению кадрового учета и подготовке всех необходимых документов по персоналу. Наши специалисты обеспечат соблюдение всех трудовых норм и требований законодательства.</p>
            <ul>
                <li>Ведение личных дел сотрудников</li>
                <li>Подготовка трудовых договоров и дополнительных соглашений</li>
                <li>Ведение табелей учета рабочего времени</li>
                <li>Консультации по вопросам трудового законодательства</li>
            </ul>
            <p>С нашей помощью вы сможете эффективно управлять персоналом и избежать возможных юридических проблем.</p>
        `
    };

    services.forEach(service => {
        service.addEventListener('click', () => {
            const serviceType = service.getAttribute('data-service');
            if (serviceDetails[serviceType]) {
                modalText.innerHTML = serviceDetails[serviceType];
                modal.style.display = 'block';
            } else {
                modalText.innerHTML = '<p>Информация об этой услуге временно недоступна.</p>';
                modal.style.display = 'block';
            }
        });
    });

    closeButton.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});

//Слайд-шоу
let slideIndex = 0;
let autoSlideInterval;
let isAutoSliding = true;

function plusSlides(n) {
    clearInterval(autoSlideInterval);
    showSlides(slideIndex += n);
    if (isAutoSliding) {
        startAutoSlides();
    }
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("slide");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex = (n % slides.length + slides.length) % slides.length; 
    slides[slideIndex].style.display = "block";
}

function startAutoSlides() {
    autoSlideInterval = setInterval(() => {
        slideIndex++;
        showSlides(slideIndex);
    }, 3000);
}

function stopAutoSlides() {
    clearInterval(autoSlideInterval);
}

function toggleAutoSlides() {
    if (isAutoSliding) {
        stopAutoSlides();
        document.getElementById("toggle-auto").innerText = "Старт";
    } else {
        startAutoSlides();
        document.getElementById("toggle-auto").innerText = "Пауза";
    }
    isAutoSliding = !isAutoSliding;
}

showSlides(slideIndex);
startAutoSlides();

//Куки
function getCookie(name) {
    let match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) {
        return match[2];
    } else {
        return null;
    }
}

function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        let date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function acceptCookies() {
    setCookie('cookiesAccepted', 'true', 365);
    document.getElementById('cookieBanner').style.display = 'none';
}

window.onload = function() {
    if (!getCookie('cookiesAccepted')) {
        document.getElementById('cookieBanner').style.display = 'flex';
    } else {
        document.getElementById('cookieBanner').style.display = 'none';
    }
}



