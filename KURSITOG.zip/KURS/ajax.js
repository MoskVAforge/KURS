$(document).ready(function() {
    $("#feedbackForm").on("submit", function(event) {
        event.preventDefault(); // Предотвращаем отправку формы по умолчанию

        $.ajax({
            url: "http://localhost:3000/send-feedback", // URL сервера, который будет обрабатывать запрос
            type: "POST", // Тип запроса
            data: $(this).serialize(), // Данные формы
            success: function(response) {
                alert("Сообщение успешно отправлено!");
                $("#feedbackForm")[0].reset(); // Очищаем форму
            },
            error: function(xhr, status, error) {
                alert("Произошла ошибка при отправке данных: " + error);
            }
        });
    });
});