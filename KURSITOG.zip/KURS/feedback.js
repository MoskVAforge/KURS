// document.getElementById('feedbackForm').addEventListener('submit', function(event) {
//     event.preventDefault();
//     alert('Спасибо за ваше сообщение! Наши специалисты свяжутся с Вами в ближайшее время');
//     document.getElementById('feedbackForm').reset();
// });
