const express = require('express');
const router = express.Router();

// Middleware функция для обработки запроса на вход
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    res.status(200).json({ message: 'Вход выполнен успешно' });
    // Ваш код для обработки запроса на вход
});

// Middleware функция для обработки запроса на регистрацию
router.post('/register', (req, res) => {
    const { username, password, email } = req.body;
    res.status(200).json({ message: 'Регистрация успешна' });
    // Ваш код для обработки запроса на регистрацию
});

// Обработчик для GET-запросов на корневой URL
router.get('/', (req, res) => {
    res.status(200).send('Добро пожаловать на сервер');
});

module.exports = router;
